import React from "react";
import "./Task.css";

function Task() {
  return (
    <div id="task">
      <div className="project-name">
        <label for="pname"> Project:</label>
        <input type="text" id="pname" placeholder="Enter Project Name.." />
      </div>

      <div className="task-name">
        <label for="tname"> Task Name:</label>
        <input type="text" id="tname" placeholder="Enter Task Name.." />
      </div>

      <div className="description">
        <label for="dname"> Description:</label>
        <input
          type="text"
          id="dname"
          placeholder="Enter about your project details.."
        />
      </div>

      <div className="task-hour">
        <label for="thour">Task Hour:</label>
        <input
          type="text"
          id="thour"
          placeholder="Expected hour to complete the task"
        />
      </div>

      <div className="task-cost">
        <label for="tcost"> Task Cost:</label>
        <input type="text" id="tcost" placeholder="Write cost for the task.." />
      </div>

      <div className="task-completed">
        <label for="tcompleted"> completed ?</label>
        <input type="text" id="tcompleted" placeholder="Write task status.." />
      </div>

      <div className="employee-select">
        <label for="eselect"> Employee: </label>
        <select classname="eselect">
          <option value="volvo">Volvo</option>
          <option value="saab">Saab</option>
          <option value="mercedes">Mercedes</option>
          <option value="audi">Audi</option>
        </select>
      </div>

      <div className="submit">
        <button className="submit-button">Submit</button>
      </div>
    </div>
  );
}

export default Task;
