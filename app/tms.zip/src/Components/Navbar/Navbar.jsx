import React from "react";
import { NavLink } from "react-router-dom";
import "./Navbar.css";

function Navbar() {
  return (
    <div id="navbar">
      <div className="left-navbar">
        <img
          src="https://cdn-icons-png.flaticon.com/512/906/906334.png"
          alt="logo"
        />
        <h3> Task Management System</h3>
      </div>

      <div className="right-navbar">
        <div>
          <NavLink to="/"> Home</NavLink>
        </div>
        <div>
          <NavLink to="/work"> Work</NavLink>
        </div>
        <div>
          <NavLink to="/project"> Project</NavLink>
        </div>
        <div>
          <NavLink to="/task"> Task</NavLink>
        </div>
        <div>
          <NavLink to="/payment"> Payment</NavLink>
        </div>
      </div>
    </div>
  );
}

export default Navbar;
