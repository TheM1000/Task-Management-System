import React from "react";

function Work() {
  return <div></div>;
}

export default Work;
