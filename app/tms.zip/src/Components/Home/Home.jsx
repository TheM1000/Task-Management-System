import React from "react";
import { Link } from "react-router-dom";
import "./Home.css";

function Home() {
  return (
    <div id="home">
      <div className="description">
        <h1>
          Help Workers Manage <br></br> Their Task.
        </h1>
        <p>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Veritatis
          dolore, quod non explicabo sed sapiente alias accusantium mollitia
          quos est iste voluptas architecto! Vitae impedit ratione libero ipsum,
          exercitationem a.
        </p>
        <Link>Learn More </Link>
      </div>

      <div className="image">
        <img
          src="https://png.pngtree.com/png-vector/20220720/ourmid/pngtree-task-management-abstract-concept-vector-illustration-png-image_6026871.png"
          alt="logo"
        />
      </div>
    </div>
  );
}

export default Home;
