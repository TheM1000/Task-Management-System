import React from "react";
import "./Project.css";

function Project() {
  return (
    <div id="project">
      <div className="project-name">
        <label for="pname"> Project Name:</label>
        <input type="text" id="pname" placeholder="Enter Project Name.." />
      </div>

      <div className="description">
        <label for="dname"> Description:</label>
        <input
          type="text"
          id="dname"
          placeholder="Enter about your project details.."
        />
      </div>

      <div className="budget">
        <label for="pbudget">Budget:</label>
        <input type="text" id="pbudget" placeholder="Enter project budget.." />
      </div>

      <div className="end-date">
        <label for="penddate"> End Date:</label>
        <input
          type="text"
          id="penddate"
          placeholder="Write project end date.."
        />
      </div>

      <div className="total-cost">
        <label for="pcost"> Total Cost:</label>
        <input type="text" id="pcost" placeholder="Write project cost.." />
      </div>

      <div className="submit">
        <button className="submit-button">Submit</button>
      </div>
    </div>
  );
}

export default Project;
